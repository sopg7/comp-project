# comp-project

- by Sophie Gu and Alice Jiang
- crawler: crawl('absolute-link')
- search engine: python3 search('phrase', boost(True/False))